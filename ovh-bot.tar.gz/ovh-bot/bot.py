#!/usr/bin/env python3
"""
OVH 服务器抢购脚本 v2
- 支持 IE/EU/CA/US 所有区域
- 支持多配置组合（NVMe/HDD 等）同时监控
- 通过 Telegram Bot 接收服务器信息自动下单锁定
- 自动处理 requiredConfiguration / eco/options

用法:
  1. 复制 config.example.toml 为 config.toml 并填入配置
  2. python3 bot.py

Telegram 命令:
  /buy <planCode> [datacenter] [os]       - 立即抢购
  /check <planCode>                        - 检查服务器所有配置的可用性
  /catalog [category]                      - 查看服务器目录
  /pay <orderId>                           - 获取付款链接
  /help                                    - 帮助信息

也可以直接转发 OVH 的服务器信息，Bot 会自动解析并下单。
"""

import json
import logging
import os
import re
import sys
import time
import traceback
import asyncio
from pathlib import Path
from datetime import datetime

import requests
import ovh

# ============================================================
# 日志配置
# ============================================================
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("ovh-bot")

# ============================================================
# 配置加载
# ============================================================
# 配置文件路径（Docker 挂载目录优先）
CONFIG_PATHS = [
    Path("/app/data/config.toml"),   # Docker 挂载
    Path(__file__).parent / "config.toml",  # 本地开发
]


def parse_toml_simple(path: str) -> dict:
    """简易 TOML 解析器"""
    config = {}
    current_section = None
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r'^\[(\w+)\]$', line)
            if m:
                current_section = m.group(1)
                config[current_section] = {}
                continue
            m = re.match(r'^(\w+)\s*=\s*(.+)$', line)
            if m:
                key = m.group(1)
                val = m.group(2).strip()
                if ' #' in val:
                    val = val[:val.index(' #')].strip()
                if val.startswith('"') and val.endswith('"'):
                    val = val[1:-1]
                elif val.isdigit():
                    val = int(val)
                elif val == "true":
                    val = True
                elif val == "false":
                    val = False
                elif val.startswith("["):
                    inner = val[1:-1].strip()
                    if inner:
                        val = [v.strip().strip('"').strip("'") for v in inner.split(",")]
                    else:
                        val = []
                if current_section:
                    config[current_section][key] = val
                else:
                    config[key] = val
    return config


def load_config() -> dict:
    """加载配置，优先级: 环境变量 > config.toml > 默认值"""
    # 按优先级查找配置文件
    cfg = {}
    for cp in CONFIG_PATHS:
        if cp.exists():
            cfg = parse_toml_simple(str(cp))
            break

    def env(key, section=None):
        val = os.environ.get(key, "")
        if val:
            if section and section not in cfg:
                cfg[section] = {}
            if section:
                cfg[section][key.split("_")[-1].lower()] = val
            return val
        return None

    env("OVH_ENDPOINT", "ovh")
    env("OVH_APPLICATION_KEY", "ovh")
    env("OVH_APPLICATION_SECRET", "ovh")
    env("OVH_CONSUMER_KEY", "ovh")
    env("OVH_ZONE", "ovh")
    env("TG_BOT_TOKEN", "telegram")
    env("TG_ALLOWED_USERS", "telegram")

    if "telegram" in cfg and "allowed_users" in cfg["telegram"]:
        users = cfg["telegram"]["allowed_users"]
        if isinstance(users, str):
            cfg["telegram"]["allowed_users"] = [int(u.strip()) for u in users.split(",") if u.strip()]
        elif isinstance(users, list):
            cfg["telegram"]["allowed_users"] = [int(u) for u in users]
    return cfg


# ============================================================
# 常量
# ============================================================
# 数据中心 → 区域映射
EU_DATACENTERS = {"gra", "rbx", "sbg", "eri", "lim", "waw", "par", "fra", "lon"}
CANADA_DATACENTERS = {"bhs"}
US_DATACENTERS = {"vin", "hil"}
APAC_DATACENTERS = {"syd", "sgp", "ynm"}

# Zone → ovhSubsidiary 映射
ZONE_MAP = {
    "IE": "IE", "FR": "FR", "DE": "DE", "UK": "UK",
    "PL": "PL", "ES": "ES", "IT": "IT", "PT": "PT",
    "NL": "NL", "CZ": "CZ", "FI": "FI", "LT": "LT",
    "CA": "CA", "US": "US", "AU": "AU", "SG": "SG",
    "IN": "IN",
}

# endpoint 映射
ENDPOINT_MAP = {
    "ovh-eu": "https://eu.api.ovh.com",
    "ovh-ca": "https://ca.api.ovh.com",
    "ovh-us": "https://api.us.ovhcloud.com",
}

# 可用性状态排除
UNAVAILABLE_STATES = {"unavailable", "unknown"}


def get_region_for_dc(dc: str) -> str:
    """根据数据中心代码推断区域"""
    dc_lower = dc.lower()
    if any(dc_lower.startswith(p) for p in EU_DATACENTERS):
        return "europe"
    elif any(dc_lower.startswith(p) for p in CANADA_DATACENTERS):
        return "canada"
    elif any(dc_lower.startswith(p) for p in US_DATACENTERS):
        return "usa"
    elif any(dc_lower.startswith(p) for p in APAC_DATACENTERS):
        return "apac"
    return ""


def format_storage(storage: str) -> str:
    """格式化存储显示"""
    if not storage or storage == "N/A":
        return "N/A"
    s = storage.lower()
    if "nvme" in s:
        # softraid-2x500nvme → 2x500GB NVMe
        m = re.search(r'(\d+)x(\d+)(nvme)', s)
        if m:
            return f"{m.group(1)}x{m.group(2)}GB NVMe"
    if "sas" in s or "sa" in s:
        m = re.search(r'(\d+)x(\d+)', s)
        if m:
            size = int(m.group(2))
            unit = "TB" if size >= 1000 else "GB"
            val = size // 1000 if size >= 1000 else size
            return f"{m.group(1)}x{val}{unit} {'SAS' if 'sas' in s else 'HDD'}"
    if "hybrid" in s:
        return storage.replace("hybridsoftraid-", "").replace("-", " + ")
    return storage


def format_memory(memory: str) -> str:
    """格式化内存显示"""
    if not memory or memory == "N/A":
        return "N/A"
    m = re.search(r'ram-(\d+)', memory.lower())
    if m:
        size = int(m.group(1))
        unit = "GB" if size < 1000 else "TB"
        val = size if size < 1000 else size // 1000
        ecc = "ECC" if "ecc" in memory.lower() else ""
        return f"{val}{unit} {'DDR4' if 'ddr4' in memory.lower() else ''} {ecc}".strip()
    return memory


def storage_matches(storage_raw: str, target: str) -> bool:
    """检查存储配置是否匹配用户指定类型

    支持的 target:
      - None/"" → 不限制，匹配所有
      - "nvme" → 匹配任何 NVMe
      - "hdd" → 匹配任何 HDD/SAS
      - "2x500nvme" → 精确匹配 2x500...nvme
      - "2x4hdd" → 匹配 2x4000sa (2x4TB HDD)
    """
    if not target or not storage_raw:
        return True

    s = storage_raw.lower().replace(" ", "")
    t = target.lower().replace(" ", "").replace("gb", "").replace("tb", "")

    # 简单类型匹配
    if t == "nvme":
        return "nvme" in s
    if t in ("hdd", "sas"):
        return ("nvme" not in s) and ("sa" in s)

    # 精确匹配: 2x500nvme → 在原始 storage 中查找
    if re.match(r'\d+x\d+nvme', t):
        # 提取数字部分: 2x500nvme → 2x500
        m = re.match(r'(\d+x\d+)nvme', t)
        if m:
            prefix = m.group(1)
            return prefix in s and "nvme" in s
        return t in s

    # HDD 精确匹配: 2x4hdd → 查找 2x4000sa (4TB = 4000)
    if re.match(r'\d+x\d+hdd', t):
        m = re.match(r'(\d+)x(\d+)hdd', t)
        if m:
            count = m.group(1)
            tb_val = int(m.group(2))
            # TB → 期望的数字: 4TB = 4000, 2TB = 2000
            sa_val = str(tb_val * 1000)
            return f"{count}x{sa_val}" in s and "sa" in s
        return t in s

    # 兜底: 子串匹配
    return t in s


def memory_matches(memory_raw: str, target: str) -> bool:
    """检查内存配置是否匹配用户指定大小

    支持的 target:
      - None/"" → 不限制
      - "32g" / "32gb" → 匹配 32GB
      - "64g" / "64gb" → 匹配 64GB
    """
    if not target or not memory_raw:
        return True

    m = re.search(r'ram-(\d+)', memory_raw.lower())
    if not m:
        return False

    mem_size = int(m.group(1))
    t = target.lower().replace(" ", "").replace("gb", "").replace("g", "")
    if t.isdigit():
        target_size = int(t)
        # "32g" → 目标 32GB → ram-32g 或 ram-32000m → 都=32
        return mem_size == target_size
    return True


# ============================================================
# OVH API 客户端 v2
# ============================================================
class OVHClient:
    """OVH API 封装 - 完整支持多区域、多配置"""

    def __init__(self, cfg: dict):
        ovh_cfg = cfg.get("ovh", {})
        self.endpoint = ovh_cfg.get("endpoint", "ovh-eu")
        self.ak = ovh_cfg.get("application_key", "")
        self.as_ = ovh_cfg.get("application_secret", "")
        self.ck = ovh_cfg.get("consumer_key", "")
        self.zone = ovh_cfg.get("zone", "IE").upper()  # ovhSubsidiary

        if not all([self.ak, self.as_, self.ck]):
            logger.warning("OVH API 凭证不完整，部分功能不可用")

        self.client = ovh.Client(
            endpoint=self.endpoint,
            application_key=self.ak,
            application_secret=self.as_,
            consumer_key=self.ck,
        )

        self.defaults = cfg.get("defaults", {})

    @property
    def subsidiary(self) -> str:
        """获取 ovhSubsidiary"""
        return ZONE_MAP.get(self.zone, self.zone)

    def _call(self, method: str, path: str, **kwargs):
        """统一 API 调用 - 使用 ovh 库的便捷方法支持 kwargs"""
        try:
            m = method.upper()
            if m == "GET":
                return self.client.get(path, **kwargs)
            elif m == "POST":
                return self.client.post(path, **kwargs)
            elif m == "PUT":
                return self.client.put(path, **kwargs)
            elif m == "DELETE":
                return self.client.delete(path, **kwargs)
            else:
                raise ValueError(f"不支持的 HTTP 方法: {method}")
        except ovh.exceptions.APIError as e:
            logger.error(f"API 调用失败: {method} {path} -> {e}")
            raise

    def get(self, path, **kwargs):
        return self._call("GET", path, **kwargs)

    def post(self, path, **kwargs):
        return self._call("POST", path, **kwargs)

    def put(self, path, **kwargs):
        return self._call("PUT", path, **kwargs)

    def delete(self, path, **kwargs):
        return self._call("DELETE", path, **kwargs)

    # ---- 可用性检查 (修复版：返回所有配置) ----
    def check_availability(self, plan_code: str) -> list:
        """
        检查服务器所有配置组合的可用性

        返回 list of dict:
        [
            {
                "fqn": "24ska01.ram-32g-ecc-2400.softraid-2x450nvme",
                "memory": "ram-32g-ecc-2400",
                "storage": "softraid-2x450nvme",
                "datacenters": {"bhs": "unavailable", "gra": "available", ...},
            },
            ...
        ]
        """
        path = "/dedicated/server/datacenter/availabilities"
        try:
            availabilities = self.get(path, planCode=plan_code)
        except Exception as e:
            logger.error(f"可用性查询失败: {e}")
            return []

        if not availabilities:
            return []

        results = []
        for item in availabilities:
            memory = item.get("memory", "N/A")
            storage = item.get("storage", "N/A")
            fqn = item.get("fqn", "")

            dcs = {}
            for dc_info in item.get("datacenters", []):
                dc_name = dc_info.get("datacenter")
                avail = dc_info.get("availability", "unknown")
                if dc_name:
                    dcs[dc_name] = avail

            results.append({
                "fqn": fqn,
                "memory": memory,
                "storage": storage,
                "datacenters": dcs,
            })

        return results

    def find_available_configs(self, plan_code: str, target_dc: str = None,
                               target_storage: str = None,
                               target_memory: str = None) -> list:
        """找出所有有货且符合指定存储/内存配置的组合

        target_storage: "nvme" / "hdd" / "2x500nvme" / "2x4hdd" 等
        target_memory: "32g" / "64g" 等
        """
        all_configs = self.check_availability(plan_code)
        available = []

        for cfg in all_configs:
            if not storage_matches(cfg["storage"], target_storage):
                continue
            if not memory_matches(cfg["memory"], target_memory):
                continue

            for dc, status in cfg["datacenters"].items():
                if status in UNAVAILABLE_STATES:
                    continue
                if target_dc and dc != target_dc:
                    continue
                available.append({
                    "fqn": cfg["fqn"],
                    "memory": cfg["memory"],
                    "storage": cfg["storage"],
                    "datacenter": dc,
                    "availability": status,
                    "memory_display": format_memory(cfg["memory"]),
                    "storage_display": format_storage(cfg["storage"]),
                })

        return available

    def get_catalog(self, category: str = "eco") -> dict:
        """获取服务器目录"""
        path = f"/order/catalog/public/{category}"
        try:
            return self.get(path, ovhSubsidiary=self.subsidiary)
        except Exception as e:
            logger.error(f"获取目录失败: {e}")
            return {}

    def get_plan_addon_families(self, plan_code: str, category: str = "eco") -> list:
        """获取 planCode 的 addonFamilies（用于查找硬件选项）"""
        try:
            catalog = self.get_catalog(category)
            for plan in catalog.get("plans", []):
                if plan.get("planCode") == plan_code:
                    return plan.get("addonFamilies", [])
        except Exception:
            pass
        return []

    # ---- 下单流程（完整版） ----
    def create_cart(self) -> dict:
        """创建购物车"""
        path = "/order/cart"
        body = {
            "ovhSubsidiary": self.subsidiary,
            "description": f"ovh-bot-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        }
        result = self.post(path, **body)
        logger.info(f"购物车已创建: {result.get('cartId')}")
        return result

    def add_eco_server(self, cart_id: str, plan_code: str,
                       datacenter: str = None, os_name: str = None,
                       duration: str = None, quantity: int = 1,
                       options: list = None) -> dict:
        """
        添加 Eco 服务器到购物车（完整流程）

        Args:
            cart_id: 购物车 ID
            plan_code: 服务器 planCode
            datacenter: 数据中心代码
            os_name: 操作系统
            duration: 时长
            quantity: 数量
            options: 硬件选项列表，如 ["ram-64g-ecc-3200-24rise", "softraid-2x960nvme-24rise"]
        """
        datacenter = datacenter or self.defaults.get("datacenter", "bhs")
        os_name = os_name or self.defaults.get("os", "none_64.en")
        duration = duration or self.defaults.get("duration", "P1M")

        # 1. 添加基础商品
        path = f"/order/cart/{cart_id}/eco"
        body = {
            "planCode": plan_code,
            "duration": duration,
            "pricingMode": "default",
            "quantity": quantity,
        }
        item_result = self.post(path, **body)
        item_id = item_result["itemId"]
        logger.info(f"已添加 Eco 服务器 {plan_code} 到购物车 {cart_id}, itemId={item_id}")

        # 2. 设置必需配置 (requiredConfiguration)
        region = get_region_for_dc(datacenter)
        configurations = {
            "dedicated_datacenter": datacenter,
            "dedicated_os": os_name,
        }
        if region:
            configurations["region"] = region

        for label, value in configurations.items():
            try:
                self.post(
                    f"/order/cart/{cart_id}/item/{item_id}/configuration",
                    label=label,
                    value=str(value),
                )
                logger.info(f"设置配置: {label} = {value}")
            except Exception as e:
                logger.warning(f"设置配置 {label} 失败: {e}")

        # 3. 添加硬件选项 (eco/options)
        if options and isinstance(options, list):
            hardware_options = self._filter_hardware_options(options)
            if hardware_options:
                try:
                    available_opts = self.get(
                        f"/order/cart/{cart_id}/eco/options",
                        planCode=plan_code,
                    )
                    logger.info(f"可用选项数: {len(available_opts)}")

                    added = 0
                    for wanted in hardware_options:
                        for avail in available_opts:
                            avail_pc = avail.get("planCode", "")
                            if avail_pc == wanted:
                                try:
                                    self.post(
                                        f"/order/cart/{cart_id}/eco/options",
                                        itemId=item_id,
                                        planCode=avail_pc,
                                        duration=avail.get("duration", duration),
                                        pricingMode=avail.get("pricingMode", "default"),
                                        quantity=1,
                                    )
                                    added += 1
                                    logger.info(f"添加硬件选项: {avail_pc}")
                                    break
                                except Exception as e:
                                    logger.warning(f"添加选项 {avail_pc} 失败: {e}")
                    logger.info(f"成功添加 {added}/{len(hardware_options)} 个硬件选项")
                except Exception as e:
                    logger.warning(f"获取 Eco 选项失败: {e}")

        return item_result

    def _filter_hardware_options(self, options: list) -> list:
        """过滤出硬件选项（排除软件/许可证）"""
        skip_terms = [
            "windows-server", "sql-server", "cpanel-license", "plesk-",
            "-license-", "os-", "control-panel", "panel", "license", "security",
        ]
        filtered = []
        for opt in options:
            if not opt or not isinstance(opt, str):
                continue
            opt_lower = opt.lower()
            if any(t in opt_lower for t in skip_terms):
                continue
            filtered.append(opt)
        return filtered

    def add_dedicated_server(self, cart_id: str, plan_code: str,
                             datacenter: str = None, os_name: str = None,
                             duration: str = None, quantity: int = 1) -> dict:
        """添加独立服务器到购物车"""
        datacenter = datacenter or self.defaults.get("datacenter", "bhs")
        os_name = os_name or self.defaults.get("os", "none_64.en")
        duration = duration or self.defaults.get("duration", "P1M")

        path = f"/order/cart/{cart_id}/dedicated/server"
        body = {
            "planCode": plan_code,
            "duration": duration,
            "pricingMode": "default",
            "quantity": quantity,
        }
        item_result = self.post(path, **body)
        item_id = item_result["itemId"]
        logger.info(f"已添加独立服务器 {plan_code} 到购物车 {cart_id}, itemId={item_id}")

        # 设置必需配置
        region = get_region_for_dc(datacenter)
        configurations = {
            "dedicated_datacenter": datacenter,
            "dedicated_os": os_name,
        }
        if region:
            configurations["region"] = region

        for label, value in configurations.items():
            try:
                self.post(
                    f"/order/cart/{cart_id}/item/{item_id}/configuration",
                    label=label,
                    value=str(value),
                )
            except Exception as e:
                logger.warning(f"设置配置 {label} 失败: {e}")

        return item_result

    def assign_cart(self, cart_id: str) -> dict:
        """分配购物车给当前用户"""
        return self.post(f"/order/cart/{cart_id}/assign")

    def checkout(self, cart_id: str, auto_pay: bool = False, waive_retract: bool = True) -> dict:
        """结账生成订单"""
        return self.post(
            f"/order/cart/{cart_id}/checkout",
            autoPayWithPreferredPaymentMethod=auto_pay,
            waiveRetractationPeriod=waive_retract,
        )

    def get_cart(self, cart_id: str) -> dict:
        return self.get(f"/order/cart/{cart_id}")

    def get_cart_summary(self, cart_id: str) -> dict:
        return self.get(f"/order/cart/{cart_id}/summary")

    def get_order(self, order_id: int) -> dict:
        return self.get(f"/me/order/{order_id}")

    def get_order_status(self, order_id: int) -> str:
        return self.get(f"/me/order/{order_id}/status")

    def get_payment_url(self, order_id: int) -> str:
        try:
            return self.get(f"/me/order/{order_id}/url")
        except Exception:
            return f"https://www.ovh.com/cgi-bin/order/payment.cgi?orderId={order_id}"

    def delete_cart(self, cart_id: str) -> dict:
        return self.delete(f"/order/cart/{cart_id}")

    # ---- 一键抢购（支持指定存储/内存） ----
    def quick_buy(self, plan_code: str, server_type: str = "eco",
                  datacenter: str = None, os_name: str = None,
                  options: list = None, target_dc: str = None,
                  target_storage: str = None,
                  target_memory: str = None) -> dict:
        """
        一键抢购 - 支持指定存储和内存配置

        Args:
            target_storage: 存储类型过滤: "nvme" / "hdd" / "2x500nvme" / "2x4hdd"
            target_memory: 内存大小过滤: "32g" / "64g"
        """
        result = {
            "success": False,
            "plan_code": plan_code,
            "server_type": server_type,
            "datacenter": datacenter or target_dc or self.defaults.get("datacenter", "bhs"),
            "config_info": None,
            "cart_id": None,
            "order_id": None,
            "payment_url": None,
            "price": None,
            "error": None,
            "elapsed": 0,
        }

        start_time = time.time()

        try:
            # 步骤 0: 检查可用性（按指定存储/内存过滤）
            dc = datacenter or target_dc
            available = self.find_available_configs(
                plan_code, target_dc=dc,
                target_storage=target_storage,
                target_memory=target_memory,
            )
            if not available:
                filter_desc = []
                if target_storage:
                    filter_desc.append(f"存储={target_storage}")
                if target_memory:
                    filter_desc.append(f"内存={target_memory}")
                if dc:
                    filter_desc.append(f"机房={dc}")
                filter_str = " ".join(filter_desc) if filter_desc else "全部配置"
                result["error"] = f"`{plan_code}` 指定配置({filter_str})当前无货"

                all_configs = self.check_availability(plan_code)
                if all_configs:
                    result["all_configs"] = all_configs
                result["elapsed"] = round(time.time() - start_time, 2)
                return result

            # 选择第一个符合条件且有货的配置
            chosen = available[0]
            actual_dc = chosen["datacenter"]
            result["datacenter"] = actual_dc
            result["config_info"] = {
                "memory_display": chosen["memory_display"],
                "storage_display": chosen["storage_display"],
                "memory": chosen["memory"],
                "storage": chosen["storage"],
            }
            logger.info(f"✅ 选择配置: {chosen['memory_display']} + {chosen['storage_display']} @ {actual_dc}")

            effective_options = options
            if not effective_options:
                effective_options = self._find_addon_options(
                    plan_code, chosen["memory"], chosen["storage"]
                )

            # 步骤 1: 创建购物车
            cart = self.create_cart()
            cart_id = cart["cartId"]
            result["cart_id"] = cart_id

            # 步骤 2: 添加服务器（带指定配置）
            if server_type == "eco":
                self.add_eco_server(
                    cart_id, plan_code,
                    datacenter=actual_dc,
                    os_name=os_name,
                    options=effective_options,
                )
            else:
                self.add_dedicated_server(
                    cart_id, plan_code,
                    datacenter=actual_dc,
                    os_name=os_name,
                )

            # 步骤 3: 分配购物车
            if self.defaults.get("auto_assign", True):
                self.assign_cart(cart_id)

            # 步骤 4: 获取价格
            try:
                summary = self.get_cart_summary(cart_id)
                prices = summary.get("prices", {})
                with_tax = prices.get("withTax", {})
                result["price"] = {
                    "withTax": with_tax.get("value") if isinstance(with_tax, dict) else with_tax,
                    "currencyCode": with_tax.get("currencyCode", "EUR") if isinstance(with_tax, dict) else "EUR",
                }
            except Exception as e:
                logger.warning(f"获取价格失败: {e}")

            # 步骤 5: 结账
            if self.defaults.get("auto_checkout", True):
                order = self.checkout(cart_id, auto_pay=False)
                result["order_id"] = order.get("orderId")
                result["payment_url"] = self.get_payment_url(order.get("orderId"))

            result["success"] = True

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"抢购失败: {e}\n{traceback.format_exc()}")

        result["elapsed"] = round(time.time() - start_time, 2)
        return result

    def _find_addon_options(self, plan_code: str, memory: str, storage: str) -> list:
        """从 catalog 中查找匹配的 addon options"""
        options = []
        try:
            families = self.get_plan_addon_families(plan_code)
            for family in families:
                family_name = family.get("name", "").lower()
                addons = family.get("addons", [])
                if family_name == "memory" and memory and memory != "N/A":
                    mem_key = self._standardize(memory)
                    for addon in addons:
                        if self._standardize(addon) == mem_key:
                            options.append(addon)
                            break
                elif family_name == "storage" and storage and storage != "N/A":
                    stor_key = self._standardize(storage)
                    for addon in addons:
                        if self._standardize(addon) == stor_key:
                            options.append(addon)
                            break
        except Exception as e:
            logger.warning(f"查找 addon options 失败: {e}")
        return options

    @staticmethod
    def _standardize(config_str: str) -> str:
        """标准化配置字符串用于匹配"""
        if not config_str:
            return ""
        s = config_str.lower().strip()
        # 移除型号后缀
        patterns = [
            r'-\d+sk[a-z]+\d*', r'-\d+rise\d*', r'-\d+sys\w*',
            r'-\d+ska\d*', r'-\d+skstor\d*', r'-\d+skgame\d*',
            r'-\d+skc\d+', r'-\d+skb\d+', r'-ks\d+', r'-v\d+',
            r'-[a-z]{3}$',
        ]
        for p in patterns:
            s = re.sub(p, '', s)
        s = re.sub(r'-(no)?ecc-\d+', '', s)
        s = re.sub(r'-\d{4,5}$', '', s)
        return s


# ============================================================
# 消息解析辅助函数
# ============================================================
PLAN_CODE_PATTERNS = [
    r'\b(24s[a-z]{2,3}\d{2}(?:-v\d+)?)\b',
    r'\b(25s[a-z]{2,3}\d{2}(?:-v\d+)?)\b',
    r'\b(rise-\d+)\b',
    r'\b(advance-\d+)\b',
    r'\b(scale-\d+)\b',
    r'\b(game-\d+)\b',
    r'\b(stor-\d+)\b',
    r'\b(ks-[a-z\d]+(?:-[a-z\d]+)*)\b',
    r'\b(bv-\d+)\b',
    r'\b(host-\d+)\b',
    r'\b(grf-\d+)\b',
    r'\b(hgr-[a-z]+-\d+)\b',
]

DATACENTER_MAP = {
    "bhs": "bhs", "beauharnois": "bhs", "加拿大": "bhs",
    "gra": "gra", "gravelines": "gra",
    "sbg": "sbg", "strasbourg": "sbg", "斯特拉斯堡": "sbg",
    "rbx": "rbx", "roubaix": "rbx",
    "par": "par", "paris": "par", "巴黎": "par",
    "fra": "fra", "frankfurt": "fra", "法兰克福": "fra",
    "lon": "lon", "london": "lon", "伦敦": "lon",
    "waw": "waw", "warsaw": "waw", "华沙": "waw",
    "eri": "eri", "erlangen": "eri",
    "vin": "vin", "vint-hill": "vin",
    "sgp": "sgp", "singapore": "sgp", "新加坡": "sgp",
    "syd": "syd", "sydney": "syd",
    "ynm": "ynm", "mumbai": "ynm", "孟买": "ynm",
}

DC_DISPLAY_MAP = {
    "bhs": "🇨🇦 Beauharnois (加拿大)",
    "gra": "🇫🇷 Gravelines (法国)",
    "sbg": "🇫🇷 Strasbourg (法国)",
    "rbx": "🇫🇷 Roubaix (法国)",
    "par": "🇫🇷 Paris (法国)",
    "fra": "🇩🇪 Frankfurt (德国)",
    "lon": "🇬🇧 London (英国)",
    "waw": "🇵🇱 Warsaw (波兰)",
    "eri": "🇩🇪 Erlangen (德国)",
    "vin": "🇺🇸 Vint Hill (美国)",
    "hil": "🇩🇪 Hillersdorf (德国)",
    "sgp": "🇸🇬 Singapore (新加坡)",
    "syd": "🇦🇺 Sydney (澳大利亚)",
    "ynm": "🇮🇳 Mumbai (印度)",
}


def parse_plan_code(text: str):
    text = text.lower()
    for pattern in PLAN_CODE_PATTERNS:
        m = re.search(pattern, text)
        if m:
            return m.group(1)
    return None


def parse_datacenter(text: str):
    text = text.lower()
    for keyword, dc in DATACENTER_MAP.items():
        if keyword in text:
            return dc
    return None


def guess_server_type(plan_code: str) -> str:
    plan_code = plan_code.lower()
    if plan_code.startswith(("ks-", "bv-")):
        return "dedicated"
    return "eco"


# ============================================================
# Telegram Bot
# ============================================================
def run_bot(cfg: dict):
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        ApplicationBuilder,
        CommandHandler,
        MessageHandler,
        CallbackQueryHandler,
        ContextTypes,
        filters,
    )

    tg_cfg = cfg.get("telegram", {})
    bot_token = tg_cfg.get("bot_token", "")
    allowed_users = tg_cfg.get("allowed_users", [])

    if not bot_token:
        logger.error("未配置 Telegram Bot Token")
        sys.exit(1)

    ovh_client = OVHClient(cfg)

    def check_user(user_id: int) -> bool:
        if not allowed_users:
            return True
        return user_id in allowed_users

    async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            await update.message.reply_text("⛔ 未授权")
            return
        await update.message.reply_text(
            "🤖 *OVH 抢购 Bot v2 已就绪！*\n\n"
            "📌 *命令列表:*\n\n"
            "🛒 *下单类:*\n"
            "/buy planCode dc 存储 内存 — 一次性抢购\n"
            "/check planCode — 查看所有配置可用性\n\n"
            "📡 *监控类:*\n"
            "/watch planCode dc 存储 内存 下单数 — 开始监控\n"
            "/unwatch planCode — 取消监控\n"
            "/watchlist — 查看当前监控列表\n\n"
            "💳 *订单类:*\n"
            "/pay orderId — 获取付款链接\n"
            "/status orderId — 订单状态\n"
            "/catalog — 查看服务器目录\n\n"
            "💡 直接转发 OVH 服务器信息也可自动下单！\n"
            f"🌐 当前区域: {ovh_client.zone} / {ovh_client.subsidiary}",
            parse_mode="Markdown",
        )

    async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            return
        await start_cmd(update, context)

    async def buy_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            await update.message.reply_text("⛔ 未授权")
            return

        if not context.args:
            await update.message.reply_text(
                "用法: /buy <planCode> [dc] [存储] [内存]\n\n"
                "示例:\n"
                "  /buy 26sk10b-v1 fra nvme         → 法兰克福 NVMe 版\n"
                "  /buy 26sk10b-v1 fra hdd           → 法兰克福 HDD 版\n"
                "  /buy 26sk10b-v1 fra 2x500nvme     → 精确指定 2x500GB NVMe\n"
                "  /buy 26sk10b-v1 fra nvme 32g      → 32GB + NVMe\n"
                "  /buy 24sk202 rbx                  → 不指定存储（自动选有货）\n\n"
                "存储关键词: nvme / hdd / 2x500nvme / 2x4hdd 等\n"
                "内存关键词: 32g / 64g"
            )
            return

        plan_code = context.args[0]
        dc = context.args[1] if len(context.args) > 1 else None
        target_storage = context.args[2] if len(context.args) > 2 else None
        target_memory = context.args[3] if len(context.args) > 3 else None

        # 如果 dc 看起来是存储关键词而不是机房，自动调整
        if dc and dc.lower() in ("nvme", "hdd", "ssd", "sas") or (dc and re.match(r'\d+x\d+', dc.lower())):
            target_storage = dc
            dc = None

        server_type = guess_server_type(plan_code)

        filter_desc = f"存储={target_storage}" if target_storage else ""
        if target_memory:
            filter_desc += f" 内存={target_memory}" if filter_desc else f"内存={target_memory}"
        filter_str = f" ({filter_desc})" if filter_desc else ""

        msg = await update.message.reply_text(
            f"🚀 正在抢购 `{plan_code}`{filter_str}...",
            parse_mode="Markdown",
        )

        result = ovh_client.quick_buy(
            plan_code=plan_code,
            server_type=server_type,
            datacenter=dc,
            target_storage=target_storage,
            target_memory=target_memory,
        )

        text = _format_buy_result(result)
        await msg.edit_text(text, parse_mode="Markdown")

    async def check_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            return

        if not context.args:
            await update.message.reply_text("用法: /check <planCode>\n示例: /check 26sk10b-v1")
            return

        plan_code = context.args[0]
        msg = await update.message.reply_text(f"🔍 正在查询 `{plan_code}` 所有配置的可用性...", parse_mode="Markdown")

        all_configs = ovh_client.check_availability(plan_code)
        if not all_configs:
            await msg.edit_text(f"❌ 未获取到 `{plan_code}` 的可用性数据", parse_mode="Markdown")
            return

        text = f"📊 *{plan_code} 可用性报告*\n（共 {len(all_configs)} 个配置组合）\n\n"
        buttons = []

        for idx, cfg in enumerate(all_configs):
            mem_display = format_memory(cfg["memory"])
            stor_display = format_storage(cfg["storage"])
            stor_raw = cfg["storage"].lower()

            # 提取存储关键词，用于一键下单按钮
            stor_keyword = ""
            if "nvme" in stor_raw:
                m = re.search(r'(\d+x\d+nvme)', stor_raw)
                stor_keyword = m.group(1) if m else "nvme"
            elif "sa" in stor_raw:
                m = re.search(r'(\d+x\d+)sa', stor_raw)
                stor_keyword = (m.group(1) + "hdd") if m else "hdd"

            text += f"📦 *#{idx+1} {mem_display} + {stor_display}*\n"

            has_available = False
            for dc, status in cfg["datacenters"].items():
                dc_display = DC_DISPLAY_MAP.get(dc, dc)
                if status in UNAVAILABLE_STATES:
                    text += f"   ❌ {dc}: {status}\n"
                else:
                    has_available = True
                    text += f"   ✅ {dc}: {status}\n"
                    # 为每个有货的配置+机房添加下单按钮
                    btn_label = f"🛒#{idx+1} {stor_display} @{dc}"
                    callback = f"buy|{plan_code}|{dc}|{stor_keyword}"
                    buttons.append([InlineKeyboardButton(btn_label, callback_data=callback)])

            text += "\n"

        if not any(s not in UNAVAILABLE_STATES for cfg in all_configs for s in cfg["datacenters"].values()):
            text += "😢 当前所有配置均无货"

        reply_markup = InlineKeyboardMarkup(buttons) if buttons else None
        await msg.edit_text(text, parse_mode="Markdown", reply_markup=reply_markup)

    # ---- 内置监控器 ----
    # 监控任务: {plan_code: {"dc": str|None, "storage": str|None, "memory": str|None,
    #                         "max_orders": int, "ordered": int, "active": bool}}
    watch_tasks = {}
    watch_running = False
    watch_lock = asyncio.Lock() if hasattr(asyncio, 'Lock') else None

    async def watch_monitor_loop():
        """后台监控循环"""
        nonlocal watch_running
        while watch_running:
            try:
                for plan_code, task in list(watch_tasks.items()):
                    if not task["active"]:
                        continue
                    if task["ordered"] >= task["max_orders"]:
                        task["active"] = False
                        await _send_msg(f"🎯 `{plan_code}` 已达到下单上限 ({task['max_orders']}单)，监控自动停止")
                        continue

                    try:
                        available = ovh_client.find_available_configs(
                            plan_code,
                            target_dc=task.get("dc"),
                            target_storage=task.get("storage"),
                            target_memory=task.get("memory"),
                        )
                        if available:
                            chosen = available[0]
                            # 检查 2 分钟内是否刚下过同款
                            cooldown_key = f"{plan_code}|{chosen['datacenter']}|{chosen['fqn']}"
                            now = time.time()
                            last_order_time = task.get("_last_order_time", {})
                            if cooldown_key in last_order_time:
                                if now - last_order_time[cooldown_key] < 120:
                                    continue

                            stor_str = f" {task['storage']}" if task.get("storage") else ""
                            await _send_msg(
                                f"🔥 *监控发现 `{plan_code}` 有货！*\n"
                                f"📍 {chosen['datacenter']} | {chosen['memory_display']} + {chosen['storage_display']}\n"
                                f"🚀 正在自动下单... ({task['ordered']+1}/{task['max_orders']})"
                            )

                            server_type = guess_server_type(plan_code)
                            result = ovh_client.quick_buy(
                                plan_code=plan_code,
                                server_type=server_type,
                                datacenter=chosen["datacenter"],
                                target_storage=task.get("storage"),
                                target_memory=task.get("memory"),
                            )

                            if result["success"]:
                                task["ordered"] += 1
                                last_order_time[cooldown_key] = now
                                task["_last_order_time"] = last_order_time
                                text = _format_buy_result(result)
                                text += f"\n\n📊 监控进度: 已下 {task['ordered']}/{task['max_orders']} 单"
                                if task["ordered"] >= task["max_orders"]:
                                    task["active"] = False
                                    text += "\n🎯 已达上限，监控自动停止"
                            else:
                                text = f"❌ 监控自动下单失败: `{plan_code}`\n{result['error']}"

                            await _send_msg(text)
                    except Exception as e:
                        logger.error(f"监控 {plan_code} 出错: {e}")

            except Exception as e:
                logger.error(f"监控循环出错: {e}")

            await asyncio.sleep(10)  # 每 10 秒检查一次

    async def _send_msg(text: str):
        """发送消息到默认 chat"""
        try:
            chat_id = str(tg_cfg.get("chat_id", ""))
            if chat_id:
                await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="Markdown")
        except Exception as e:
            logger.error(f"发送监控消息失败: {e}")

    async def watch_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """开始监控服务器 - 有货自动下单，可设置下单次数"""
        if not check_user(update.effective_user.id):
            await update.message.reply_text("⛔ 未授权")
            return

        if not context.args:
            await update.message.reply_text(
                "用法: /watch <planCode> [dc] [存储] [内存] [下单数]\n\n"
                "示例:\n"
                "  /watch 26sk10b-v1 fra nvme 1     → 法兰克福 NVMe，下1单后停止\n"
                "  /watch 26sk10b-v1 nvme 2          → 不限机房 NVMe，下2单后停止\n"
                "  /watch 26sk10b-v1 fra             → 法兰克福不限存储，默认下1单\n"
                "  /watch 26sk10b-v1                 → 不限配置，默认下1单\n\n"
                "💡 默认下1单后自动停止，不会无限下单！\n"
                "   用 /unwatch 可随时取消监控"
            )
            return

        plan_code = context.args[0]
        dc = context.args[1] if len(context.args) > 1 else None
        target_storage = context.args[2] if len(context.args) > 2 else None
        target_memory = context.args[3] if len(context.args) > 3 else None
        max_orders = int(context.args[4]) if len(context.args) > 4 else 1

        # 智能参数识别：dc 可能是存储关键词
        if dc and dc.lower() in ("nvme", "hdd", "ssd", "sas"):
            target_storage = dc
            dc = None
        # target_storage 可能是 max_orders（纯数字）
        if target_memory and target_memory.isdigit():
            max_orders = int(target_memory)
            target_memory = None
        if target_storage and target_storage.isdigit():
            max_orders = int(target_storage)
            target_storage = None

        watch_tasks[plan_code] = {
            "dc": dc,
            "storage": target_storage,
            "memory": target_memory,
            "max_orders": max_orders,
            "ordered": 0,
            "active": True,
            "_last_order_time": {},
        }

        # 启动后台监控（如果未运行）
        nonlocal watch_running
        if not watch_running:
            watch_running = True
            asyncio.ensure_future(watch_monitor_loop())

        filter_parts = []
        if dc:
            filter_parts.append(f"机房={dc}")
        if target_storage:
            filter_parts.append(f"存储={target_storage}")
        if target_memory:
            filter_parts.append(f"内存={target_memory}")
        filter_str = f" ({', '.join(filter_parts)})" if filter_parts else ""

        await update.message.reply_text(
            f"📡 *开始监控* `{plan_code}`{filter_str}\n\n"
            f"⏱️ 检查间隔: 10秒\n"
            f"🎯 下单上限: {max_orders} 单\n"
            f"📊 已下: 0 单\n\n"
            f"💡 达到 {max_orders} 单后自动停止\n"
            f"/unwatch {plan_code} 可随时取消",
            parse_mode="Markdown",
        )

    async def unwatch_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """取消监控"""
        if not check_user(update.effective_user.id):
            return

        if not context.args:
            # 取消所有监控
            count = sum(1 for t in watch_tasks.values() if t["active"])
            if count == 0:
                await update.message.reply_text("📭 当前没有监控任务")
                return
            for pc in watch_tasks:
                watch_tasks[pc]["active"] = False
            watch_tasks.clear()
            await update.message.reply_text(f"📭 已取消所有监控 ({count} 个)")
            return

        plan_code = context.args[0]
        if plan_code in watch_tasks:
            watch_tasks[plan_code]["active"] = False
            del watch_tasks[plan_code]
            await update.message.reply_text(f"📭 已取消监控 `{plan_code}`", parse_mode="Markdown")
        else:
            await update.message.reply_text(f"⚠️ `{plan_code}` 不在监控列表中", parse_mode="Markdown")

    async def watchlist_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """查看当前监控列表"""
        if not check_user(update.effective_user.id):
            return

        if not watch_tasks:
            await update.message.reply_text("📭 当前没有监控任务\n\n用 /watch <planCode> 开始监控")
            return

        text = "📡 *当前监控列表*\n\n"
        for pc, task in watch_tasks.items():
            status = "🟢 监控中" if task["active"] else "🔴 已停止"
            filter_parts = []
            if task.get("dc"):
                filter_parts.append(f"机房={task['dc']}")
            if task.get("storage"):
                filter_parts.append(f"存储={task['storage']}")
            if task.get("memory"):
                filter_parts.append(f"内存={task['memory']}")
            filter_str = f" ({', '.join(filter_parts)})" if filter_parts else ""

            text += (
                f"{status} `{pc}`{filter_str}\n"
                f"   进度: {task['ordered']}/{task['max_orders']} 单\n\n"
            )

        await update.message.reply_text(text, parse_mode="Markdown")

    async def catalog_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            return

        category = context.args[0] if context.args else "eco"
        msg = await update.message.reply_text(f"📖 正在获取 {category} 服务器目录...")

        catalog = ovh_client.get_catalog(category)
        if not catalog:
            await msg.edit_text("❌ 获取目录失败")
            return

        plans = catalog.get("plans", [])
        if not plans:
            await msg.edit_text("❌ 目录为空")
            return

        text = f"📖 *{category.upper()} 服务器目录* ({len(plans)} 个)\n\n"
        for plan in plans[:30]:
            pc = plan.get("planCode", "?")
            invoice_name = plan.get("invoiceName", "")
            if invoice_name:
                text += f"• `{pc}` - {invoice_name}\n"
            else:
                text += f"• `{pc}`\n"

        if len(plans) > 30:
            text += f"\n... 还有 {len(plans) - 30} 个型号"

        await msg.edit_text(text, parse_mode="Markdown")

    async def pay_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            return
        if not context.args:
            await update.message.reply_text("用法: /pay <orderId>")
            return

        try:
            order_id = int(context.args[0])
            url = ovh_client.get_payment_url(order_id)
            await update.message.reply_text(
                f"💳 订单 `{order_id}` 付款链接:\n\n{url}\n\n⚠️ 请尽快付款！",
                parse_mode="Markdown",
            )
        except Exception as e:
            await update.message.reply_text(f"❌ 获取付款链接失败: {e}")

    async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not check_user(update.effective_user.id):
            return
        if not context.args:
            await update.message.reply_text("用法: /status <orderId>")
            return

        try:
            order_id = int(context.args[0])
            order = ovh_client.get_order(order_id)
            status = ovh_client.get_order_status(order_id)
            text = (
                f"📋 订单 {order_id}\n\n"
                f"状态: {status}\n"
                f"日期: {order.get('date', 'N/A')}"
            )
            await update.message.reply_text(text)
        except Exception as e:
            await update.message.reply_text(f"❌ 查询失败: {e}")

    async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理内联按钮回调 - 支持带存储类型的下单"""
        query = update.callback_query
        await query.answer()

        if not check_user(query.from_user.id):
            await query.answer("⛔ 未授权", show_alert=True)
            return

        data = query.data
        parts = data.split("|")

        if parts[0] == "buy" and len(parts) >= 3:
            plan_code = parts[1]
            dc = parts[2]
            target_storage = parts[3] if len(parts) > 3 else None

            filter_str = f" (指定 {target_storage})" if target_storage else ""
            await query.edit_message_text(
                f"🚀 正在抢购 `{plan_code}` @ {dc}{filter_str}...",
                parse_mode="Markdown",
            )

            server_type = guess_server_type(plan_code)
            result = ovh_client.quick_buy(
                plan_code=plan_code,
                server_type=server_type,
                datacenter=dc,
                target_storage=target_storage,
            )
            text = _format_buy_result(result)
            await query.edit_message_text(text, parse_mode="Markdown")

    async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理转发的消息，自动解析服务器信息并下单（支持存储类型识别）"""
        if not check_user(update.effective_user.id):
            return

        text = update.message.text or ""
        if not text.strip():
            return

        # 解析 planCode
        plan_code = parse_plan_code(text)
        if not plan_code:
            # 尝试特殊型号名映射
            known_plans = {
                "ks-1-b": "26sk10b-v1", "ks1b": "26sk10b-v1",
                "ks-5-a": "26sk50a-v1", "ks5a": "26sk50a-v1",
                "ks-5-b": "26sk50b-v1", "ks5b": "26sk50b-v1",
            }
            for name, pc in known_plans.items():
                if name in text.lower():
                    plan_code = pc
                    break

        if not plan_code:
            return

        # 解析数据中心
        dc = parse_datacenter(text)

        # 解析存储类型
        target_storage = None
        text_lower = text.lower()
        if "nvme" in text_lower:
            m = re.search(r'(\d+x\d+)\s*gb?\s*nvme', text_lower.replace(" ", ""))
            if m:
                target_storage = m.group(1).replace("gb", "") + "nvme"
            else:
                target_storage = "nvme"
        elif any(kw in text_lower for kw in ["hdd", "sas", "sata", "硬盘"]):
            m = re.search(r'(\d+x\d+)\s*(?:tb|gb)?\s*(?:hdd|sas|sata|硬盘)', text_lower.replace(" ", ""))
            if m:
                target_storage = m.group(1) + "hdd"
            else:
                target_storage = "hdd"

        server_type = guess_server_type(plan_code)
        filter_parts = []
        if dc:
            filter_parts.append(f"机房={dc}")
        if target_storage:
            filter_parts.append(f"存储={target_storage}")
        filter_str = f" ({', '.join(filter_parts)})" if filter_parts else ""

        msg = await update.message.reply_text(
            f"🔍 识别到: `{plan_code}`{filter_str}\n🚀 正在下单...",
            parse_mode="Markdown",
        )

        result = ovh_client.quick_buy(
            plan_code=plan_code,
            server_type=server_type,
            datacenter=dc,
            target_storage=target_storage,
        )

        reply_text = _format_buy_result(result)
        await msg.edit_text(reply_text, parse_mode="Markdown")

    def _format_buy_result(result: dict) -> str:
        if result["success"]:
            text = "✅ *抢购成功！*\n\n"
            text += f"📦 服务器: `{result['plan_code']}`\n"
            text += f"🏗️ 数据中心: {result['datacenter']} ({DC_DISPLAY_MAP.get(result['datacenter'], result['datacenter'])})\n"

            if result.get("config_info"):
                ci = result["config_info"]
                text += f"💾 内存: {ci['memory_display']}\n"
                text += f"💿 存储: {ci['storage_display']}\n"

            text += f"🛒 购物车: `{result['cart_id']}`\n"

            if result.get("price"):
                p = result["price"]
                text += f"💰 价格: {p.get('withTax', '?')} {p.get('currencyCode', 'EUR')}\n"

            if result["order_id"]:
                text += f"📋 订单号: `{result['order_id']}`\n"
            if result["payment_url"]:
                text += f"💳 付款链接: {result['payment_url']}\n"

            text += f"\n⏱️ 耗时: {result['elapsed']}s"

            if result["order_id"]:
                text += "\n\n⚠️ *请尽快手动付款以锁定订单！*"
            else:
                text += f"\n\n⚠️ 购物车已创建，请使用 /order {result['cart_id']} 生成订单"
        else:
            text = "❌ *抢购失败*\n\n"
            text += f"📦 服务器: `{result['plan_code']}`\n"
            text += f"❗ 错误: {result['error']}\n"
            text += f"⏱️ 耗时: {result['elapsed']}s"

            # 如果有所有配置信息，显示
            if result.get("all_configs"):
                text += "\n\n📊 *所有配置状态:*\n"
                for cfg in result["all_configs"]:
                    mem = format_memory(cfg["memory"])
                    stor = format_storage(cfg["storage"])
                    text += f"  {mem} + {stor}:\n"
                    for dc, status in cfg["datacenters"].items():
                        icon = "✅" if status not in UNAVAILABLE_STATES else "❌"
                        text += f"    {icon} {dc}: {status}\n"

        return text

    # ---- 构建 Bot ----
    app = ApplicationBuilder().token(bot_token).build()

    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("buy", buy_cmd))
    app.add_handler(CommandHandler("eco", buy_cmd))
    app.add_handler(CommandHandler("dedi", buy_cmd))
    app.add_handler(CommandHandler("dedicated", buy_cmd))
    app.add_handler(CommandHandler("check", check_cmd))
    app.add_handler(CommandHandler("catalog", catalog_cmd))
    app.add_handler(CommandHandler("pay", pay_cmd))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("watch", watch_cmd))
    app.add_handler(CommandHandler("unwatch", unwatch_cmd))
    app.add_handler(CommandHandler("watchlist", watchlist_cmd))
    app.add_handler(CallbackQueryHandler(button_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info(f"🤖 OVH 抢购 Bot v2 启动 (区域: {ovh_client.zone}/{ovh_client.subsidiary})")
    app.run_polling()


# ============================================================
# CLI 模式
# ============================================================
def run_cli(cfg: dict):
    import argparse

    parser = argparse.ArgumentParser(description="OVH 服务器抢购工具 v2")
    subparsers = parser.add_subparsers(dest="command")

    buy_p = subparsers.add_parser("buy", help="抢购服务器")
    buy_p.add_argument("plan_code", help="服务器 planCode")
    buy_p.add_argument("--type", choices=["eco", "dedicated"], default="eco")
    buy_p.add_argument("--dc", help="数据中心")
    buy_p.add_argument("--os", help="操作系统")
    buy_p.add_argument("--options", nargs="*", help="硬件选项列表")

    check_p = subparsers.add_parser("check", help="查看所有配置可用性")
    check_p.add_argument("plan_code", help="服务器 planCode")

    catalog_p = subparsers.add_parser("catalog", help="查看服务器目录")
    catalog_p.add_argument("--category", default="eco", help="类别")

    pay_p = subparsers.add_parser("pay", help="获取付款链接")
    pay_p.add_argument("order_id", type=int)

    status_p = subparsers.add_parser("status", help="查看订单状态")
    status_p.add_argument("order_id", type=int)

    subparsers.add_parser("bot", help="启动 Telegram Bot")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    client = OVHClient(cfg)

    if args.command == "buy":
        print(f"🚀 正在抢购 {args.plan_code}...")
        result = client.quick_buy(
            plan_code=args.plan_code,
            server_type=args.type,
            datacenter=args.dc,
            os_name=args.os,
            options=args.options,
        )
        if result["success"]:
            print(f"✅ 抢购成功！")
            print(f"   数据中心: {result['datacenter']}")
            if result.get("config_info"):
                ci = result["config_info"]
                print(f"   内存: {ci['memory_display']}")
                print(f"   存储: {ci['storage_display']}")
            print(f"   购物车: {result['cart_id']}")
            if result["order_id"]:
                print(f"   订单号: {result['order_id']}")
            if result["payment_url"]:
                print(f"   付款链接: {result['payment_url']}")
            if result.get("price"):
                p = result["price"]
                print(f"   价格: {p.get('withTax', '?')} {p.get('currencyCode', 'EUR')}")
            print(f"   耗时: {result['elapsed']}s")
        else:
            print(f"❌ 抢购失败: {result['error']}")
            print(f"   耗时: {result['elapsed']}s")
            if result.get("all_configs"):
                print(f"\n📊 所有配置状态:")
                for c in result["all_configs"]:
                    mem = format_memory(c["memory"])
                    stor = format_storage(c["storage"])
                    print(f"  {mem} + {stor}:")
                    for dc, status in c["datacenters"].items():
                        icon = "✅" if status not in UNAVAILABLE_STATES else "❌"
                        print(f"    {icon} {dc}: {status}")

    elif args.command == "check":
        print(f"🔍 检查 {args.plan_code} 所有配置可用性...")
        all_configs = client.check_availability(args.plan_code)
        if not all_configs:
            print("❌ 未获取到可用性数据")
            return
        for cfg in all_configs:
            mem = format_memory(cfg["memory"])
            stor = format_storage(cfg["storage"])
            print(f"\n  📦 {mem} + {stor}")
            for dc, status in cfg["datacenters"].items():
                icon = "✅" if status not in UNAVAILABLE_STATES else "❌"
                dc_disp = DC_DISPLAY_MAP.get(dc, dc)
                print(f"    {icon} {dc_disp}: {status}")

    elif args.command == "catalog":
        print(f"📖 获取 {args.category} 目录...")
        catalog = client.get_catalog(args.category)
        plans = catalog.get("plans", [])
        for plan in plans:
            pc = plan.get("planCode", "?")
            name = plan.get("invoiceName", "")
            print(f"  {pc} - {name}")

    elif args.command == "pay":
        try:
            url = client.get_payment_url(args.order_id)
            print(f"💳 订单 {args.order_id} 付款链接:\n   {url}")
        except Exception as e:
            print(f"❌ 获取付款链接失败: {e}")

    elif args.command == "status":
        try:
            order = client.get_order(args.order_id)
            status = client.get_order_status(args.order_id)
            print(f"📋 订单 {args.order_id}")
            print(f"   状态: {status}")
            print(f"   日期: {order.get('date', 'N/A')}")
        except Exception as e:
            print(f"❌ 查询失败: {e}")

    elif args.command == "bot":
        run_bot(cfg)


# ============================================================
# 入口
# ============================================================
if __name__ == "__main__":
    cfg = load_config()

    if len(sys.argv) == 1 and cfg.get("telegram", {}).get("bot_token"):
        print("🤖 启动 Telegram Bot 模式...")
        run_bot(cfg)
    else:
        run_cli(cfg)
